gcc -Wall -Wextra -std=c99 -g pruebas_alumno.c src/pokedex.c -o pruebas
./pruebas